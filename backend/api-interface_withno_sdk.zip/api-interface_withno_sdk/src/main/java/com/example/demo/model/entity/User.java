package com.example.demo.model.entity;

import java.io.Serializable;

import lombok.Data;

/**
 * 用户
 */
@Data
public class User implements Serializable {
    private String username;

    private static final long serialVersionUID = 1L;
}
