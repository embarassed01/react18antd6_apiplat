package com.example.demo;

import com.example.demo.client.ApiClient;
import com.example.demo.model.entity.User;

public class Main {
    public static void main(String[] args) {
        String accessKey = "victoryaccesskey";
        String secretKey = "victorysecretkey";
        ApiClient apiClient = new ApiClient(accessKey, secretKey);
        // apiClient.getNameByGet("房间看电视啦快");
        // apiClient.getNameByPost("yupi分开");
        User user = new User();
        user.setUsername("victory");
        apiClient.getUsernameByPost(user);
        /*
你的名字是房间看电视啦快
你的名字是yupi分开
Response Headers: 
    Keep-Alive=[timeout=60]
    null=[HTTP/1.1 200]
    Connection=[keep-alive]
    Vary=[Access-Control-Request-Headers, Access-Control-Request-Method, Origin]
    Content-Length=[38]
    Date=[Thu, 07 Nov 2024 22:52:24 GMT]
    Content-Type=[text/html;charset=UTF-8]
Response Body: 
    POST 用户名字是方式的教练卡

POST 用户名字是方式的教练卡
         */
    }
}
